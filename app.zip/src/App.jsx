import { useState, useEffect } from "react";
import styled from "styled-components";
import SearchResult from "./component/SearchResult/SearchResult";

export const BASE_URL = "http://localhost:9000";

const App = () => {
  const [filltedData, setFillteredData] = useState(null);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [selectedBtn, setSelectedBtn] = useState(null);

  useEffect(() => {
    const fetchFoodData = async () => {
      setLoading(true);
      try {
        const response = await fetch(BASE_URL);
        const json = await response.json();
        
        setData(json);
        setFillteredData(json);
        setLoading(false);
      } catch (error) {
        setError("Unable to fetch Data");
      }
    };
    fetchFoodData();
  }, []);

  // console.log(data);

  if (loading) return <div>Loading...</div>
  if (error) return <div>{error}</div>


  const searchFood = (e) =>{
    const searchValue = e.target.value;
    console.log(searchValue);
  if(searchValue == ""){
    setFillteredData(null);
  }


  const filter = data?.filter((food) => 
    food.name.toLowerCase().includes(searchValue.toLowerCase())
  );
  setFillteredData(filter);
  
  };

  const filterFood = (type)=>{

    if(type == "all"){
      setFillteredData(data);
      setSelectedBtn(all);
      return;
  }

  const filter = data?.filter((food) => 
    food.type.toLowerCase().includes(type.toLowerCase())
  );
  setFillteredData(filter);
  setSelectedBtn(type)
  
  };


  const filterBtns = [
    {
      name: "All",
      type: "all",
    },
    {
      name: "Breakfast",
      type: "breakfast",
    },
    {
      name: "Lunch",
      type: "lunch",
    },
    {
      name: "Dinner",
      type: "dinner",
    },

  ]

  return (
    <>
      <Container>
        <TopContainer>
          <div className="logo">
            <img src="/images/fresh-food.png" alt="Logo" />
          </div>

          <div className="search">
            <input onChange={searchFood} placeholder="Search Food.." />
          </div>
        </TopContainer>
        <FillterContainer>
          {filterBtns.map((value)=>
          <Button
          isSelected={selectedBtn == value.type}  

          key={value.name} onClick={()=> filterFood(value.type)}>
            {value.name}
          </Button>
          )}
        </FillterContainer>

        <SearchResult data= {filltedData}/>
      </Container>
    </>
  );
};

export default App;

const Container = styled.div`
  max-width: 1280px;
  margin: 0 auto;
  background-color: #ddd;
`;
const TopContainer = styled.div`
  display: flex;
  justify-content: space-around;
  align-items: center;
  padding: 16px;
  height: 140px;
  .logo img {
    width: 100px;
  }
  .search input {
    border: 1px solid #f45911;
    padding: 0.5rem;
    border-radius: 5px;
    background-color: #fff;
    
  }

@media (0 > width > 420px){
 flex-direction: column;
 height:120px;
}

`;

const FillterContainer = styled.section`
  display: flex;
  justify-content: center;
  gap: 0.75rem;
  color: #fff;
  padding-bottom: 2.5rem;
`;

export const Button = styled.section`
  border-radius: 0.3125rem;
  background-color: ${({isSelected})=> (isSelected ? "#dc3535":"#ff4343")};
  outline: 1px solid${({isSelected})=> (isSelected ? "#fff":"#ff4343")};
  padding: 0.375rem 0.75rem;
  cursor: pointer;
  &:hover {
    background-color: #dc3535;
  }
`;

