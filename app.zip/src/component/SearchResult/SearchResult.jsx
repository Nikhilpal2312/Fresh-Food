import React from 'react';
import styled from "styled-components";
import { BASE_URL, Button } from '../../App';

const SearchResult = ({data}) => {
  return (
    <div>
      <FoodCardContainer>
          <FoodCards>
            {data?.map((users) => {
              const {image,text,price,name} = users;
              return(
               <>
                <FoodCard key={name}>

                <div className="food_image">
                  <img src={BASE_URL + image} alt="Image" />
                </div>
                <div className="food_info">
                  <div className="info">
                    <h3>{name}</h3>
                    <p>{text}</p>
                  </div>
                  <div className='food_button'>
                        <Button>${price.toFixed(2)}</Button>
                        
                    </div>
                </div>


                </FoodCard>
               </>
              )
              
            })}
          </FoodCards>
        </FoodCardContainer>
    </div>
  )
}

export default SearchResult;


const FoodCardContainer = styled.section`
  background-color: #f45911;
  background-size: cover;
  min-height: calc(100vh - 100px);
  display: flex;
  justify-content: space-between;
`;

const FoodCards = styled.div`
  display: flex;
  flex-wrap: wrap;
  row-gap: 20px;
  column-gap: 32px;
  justify-content: center;
  align-items: center;
  padding-top: 3.5rem;
  margin: 0 auto;
`;

const FoodCard = styled.div`
  width: 340px;
  height: 167px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 16px;
  box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
  backdrop-filter: blur(5px);
  -webkit-backdrop-filter: blur(5px);
  border: 1px solid rgba(255, 255, 255, 0.3);
  display: flex;
  padding: 10px;
  border-radius: 5px;

  .food_info {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    align-items: end;
    color: #fff;
    font-weight: 500;
  }
  h3 {
    color: #fff;
    font-size: 1rem;
    margin: 10px;
  }
  p {
    color: #fff;
    font-size: 0.75rem;
    margin: 10px;
  }
`;
